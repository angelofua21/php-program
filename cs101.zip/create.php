<?php include 'database.php'; ?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Item</title>
</head>

<body>
    <h2>Add Lost/Found Item</h2>
    <form method="post">
        <label>Item Name:</label><br>
        <input type="text" name="item_name" required><br><br>

        <label>Description:</label><br>
        <textarea name="description"></textarea><br><br>

        <label>Location Found:</label><br>
        <input type="text" name="location_found"><br><br>

        <label>Date Found:</label><br>
        <input type="date" name="date_found"><br><br>

        <label>Contact Info:</label><br>
        <input type="text" name="contact_info"><br><br>

        <input type="submit" name="submit" value="Add Item">
    </form>

    <p><a href="index.php">Back to list</a></p>

    <?php
    if (isset($_POST['submit'])) {
        $item_name = $_POST['item_name'];
        $description = $_POST['description'];
        $location_found = $_POST['location_found'];
        $date_found = $_POST['date_found'];
        $contact_info = $_POST['contact_info'];

        $sql = "INSERT INTO items (item_name, description, location_found, date_found, contact_info)
          VALUES ('$item_name', '$description', '$location_found', '$date_found', '$contact_info')";

        if ($conn->query($sql) === TRUE) {
            echo "New item added successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>
</body>

</html>