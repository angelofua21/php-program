<?php
class Database
{
    private $host = 'localhost';  // Change if your host differs
    private $db_name = 'lost_and_found';
    private $username = 'root';  // Change to your MySQL username
    private $password = '';      // Change to your MySQL password
    public $conn;

    public function getConnection()
    {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
