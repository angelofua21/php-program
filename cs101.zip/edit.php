<?php include 'database.php'; ?>

<?php
$id = $_GET['id'];
$sql = "SELECT * FROM items WHERE id=$id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Item</title>
</head>

<body>
    <h2>Edit Item</h2>
    <form method="post">
        <label>Item Name:</label><br>
        <input type="text" name="item_name" value="<?php echo $row['item_name']; ?>"><br><br>

        <label>Description:</label><br>
        <textarea name="description"><?php echo $row['description']; ?></textarea><br><br>

        <label>Location Found:</label><br>
        <input type="text" name="location_found" value="<?php echo $row['location_found']; ?>"><br><br>

        <label>Date Found:</label><br>
        <input type="date" name="date_found" value="<?php echo $row['date_found']; ?>"><br><br>

        <label>Contact Info:</label><br>
        <input type="text" name="contact_info" value="<?php echo $row['contact_info']; ?>"><br><br>

        <input type="submit" name="update" value="Update Item">
    </form>

    <p><a href="index.php">Back to list</a></p>

    <?php
    if (isset($_POST['update'])) {
        $item_name = $_POST['item_name'];
        $description = $_POST['description'];
        $location_found = $_POST['location_found'];
        $date_found = $_POST['date_found'];
        $contact_info = $_POST['contact_info'];

        $sql = "UPDATE items SET 
            item_name='$item_name', 
            description='$description',
            location_found='$location_found',
            date_found='$date_found',
            contact_info='$contact_info'
          WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Item updated successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>
</body>

</html>